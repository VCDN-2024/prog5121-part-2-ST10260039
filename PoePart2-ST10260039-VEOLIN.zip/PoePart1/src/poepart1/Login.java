 package poepart1;

import javax.swing.JOptionPane;



public class Login {
//all variables used thru out the app
public String username;
public String password;
public String name;
public String surname;
private String TaskName;
private String TaskDesc;
private String TaskNum;
private String TaskDur;
private String TaskStat;
private String TaskID;
private String DevName;
private String DevSur;
private int TaskNumber;
private int TotalHours;
private int TotalHo;

    public Login (String username, String password)
    {
        this.username = username;
        this.password = password;
    }
  //code taht checsk if username entered meets requirements
    public static boolean checkUsername(String username)
    {
        return username != null && username.length() <=5 && username.contains("_");
        
    }
    //code that checks if password meets requirements
    public static boolean validPassword(String password)
    {
        return password != null && password.length() > 8  && password.matches(".*[A-Z].*") && password.matches(".*[a-z].*") && password.matches(".*[!@#$%^&*].*") && password.matches(".*[0-9].*");
    }
    //code that registers the user if correct password and username entered
    public String Registeruser()
    {
        if (!checkUsername(username))
        {
            return "Format not met! Please contain special characters and atleast 1 Capital letter";
        }  else {
            
        
        if ( validPassword(password))
        {
              return "Password and username successfully captured";
        }  else {
            return "Format not met! Include atleast 8 characters,a capital letter,a special character and a number ";   
        }
       
    }
    }
    
    //code that login in the user if all details met requirements
    public boolean LoginUser(String username2, String Userpassword )
    {
        if (username2.equals(username) && Userpassword.equals(password))
        {
            return true;
        } else {
            return false;
        }
        
    }
    //return !(!username2.equals(username) || !Userpassword.equals(password)); 
    public String ReturnLoginStatus(boolean loginStatus)
    {
        if (loginStatus){
           return " Welcome back";   // return " Welcome back " + username ";
        } else {
            return "Invalid credentials";
        }
    }
   
   // code for part 2
        public void setTaskName(String TaskName) {
        this.TaskName= TaskName;
    }
    public String getTaskName(){
        return TaskName;
    }
    public void setTaskDesc( String TaskDesc){
        this.TaskDesc = TaskDesc;
    }
    public String getTaskDesc(){
        return TaskDesc;
    }
    public void setDevName( String DevName){
        this.DevName= DevName;
    }
    public String getDevName(){
        return DevName;
    }
     public void setDevSur( String DevSur){
        this.DevSur= DevSur;
    }
      public String getDevSur(){
        return DevSur;
    }
    public void setTaskDur( String TaskDur){
        this.TaskDur = TaskDur;
    }
    public String getTaskDur(){
        return TaskDur;
    }
    public void setTaskStat( String TaskStat){
        this.TaskStat =TaskStat;
    }
    public String getTaskStat(){
        return TaskStat;
    }
    public void setTaskID ( String TaskID){
        this.TaskID = TaskID;
     }
    public String getTaskID (){
        return TaskID;
    }
    public void setTaskNum( String TaskNum){
        this.TaskNum = TaskNum;
    }
    public String getTaskNum (){
        return TaskNum;
    }
    public void setH( int TotalHo){
        this.TotalHo=TotalHo;
    }
    public int getTotalHo(){
        return TotalHo;
    }
    
    //method that checks the length of the task description
    public static boolean CheckTaskDesc(String TaskDesc){
        return TaskDesc != null && TaskDesc.length() <=50;
    }
    //method that creates the taskid
     public void CreateTaskId (){
        
        String first = TaskName.substring(0, Math.min(TaskName.length(), 2));
        String last = DevName.substring(DevName.length() - 3);
        String upper2 = first.toUpperCase();
        String upper3 = last.toUpperCase();
        TaskID = upper2 + ":" + TaskNumber + ":" + upper3; 
    }
     //method that prints all task details
      public String PrintTaskDetails(){
        return "Task status " + TaskStat + "\n" +
                "Developer details " + DevName + " " + DevSur  + "\n" +
                "Task Number " + TaskNumber + "\n" +
                "Task Name " + TaskName + "\n" +
                "Task Description " + TaskDesc+ "\n" +
                "Task Id "+ TaskID + "\n" +
                "Task Duration " + TaskDur;
    }
    public int ReturnTotalHours(){
        
    return TotalHours= TotalHours+ TotalHo;
    }
    
    
    public void Part2(){
        //following code creates a menu for the user to choose from either add a task, show a report or exit the app
        //following code includes asking the user to enter details about the task that they are either busy with, done or will do
        //
        do{
             String OptionInput = JOptionPane.showInputDialog("Select one of the following options (Option number only): \n1. Add Task \n2.Show Report \n3.Exit App");
          int Option = Integer.parseInt(OptionInput);
          TaskNumber = 0;
          if (Option == 1){
           int TaskNum = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of tasks you want to add"));
                      
                      //for loop thats going to increment 
                      for ( int i = 1; i<TaskNum+1; i++) {
                          if (TaskNum <= 8){
                      String TaskName1 = JOptionPane.showInputDialog("Enter Task Name");
                      setTaskName(TaskName1);
                      String TaskDesc1 = JOptionPane.showInputDialog("Enter Task Deescription");
                      
                      //if loop to check if the user entered correct length of the task description if they did the app will continue running and asking d=for more details to be entered
                      if (CheckTaskDesc(TaskDesc1)){
                           setTaskDesc(TaskDesc1);
                           TaskNumber = TaskNumber + 1;
                          JOptionPane.showMessageDialog(null, "Task Description successfully captured");
                          String DevName1 = JOptionPane.showInputDialog("Enter Developer's Name");
                      setDevName(DevName1);
                      String DevSur1 = JOptionPane.showInputDialog("Enter Developer's Last Name");
                      setDevSur(DevSur1);
                      
                      String TaskDur1 = JOptionPane.showInputDialog("Enter Task Duration");
                      setTaskDur(TaskDur1);
                      int TotalH = Integer.parseInt(TaskDur1);
                      
                      TotalHours = TotalHours + TotalH;
                      //method called to create a unique task id
                     CreateTaskId();
                     //method called that will have an additional menu and contains code to display all task details
                        Stat(); 
                        
                      }
                      
                      
                      else{
                          // if the user has entered incorrect length of task description
                         JOptionPane.showMessageDialog(null, "Please enter Task Description of 50 characters or less"); 
                      }
                       
                      } else{
                              JOptionPane.showMessageDialog(null, "Please enter less number of tasks!");
                          }
                      }
                     
            //code for menu option number 2         
          }else if (Option == 2){
              JOptionPane.showMessageDialog(null, "Coming soon");
          }
        else if (Option == 3){
              JOptionPane.showMessageDialog(null, "Sucessfully exited the App!");
              break;
          }
        }while(true);
    }
    //following code is a method that creates a menu for the user to choose whether he/she is done, still has to do or is doing their task and also displays teh task details
    public void Stat(){
        do{
            String Option2 = JOptionPane.showInputDialog("Select one of the following : \n1. Done \n2. To do \n3. Doing \n4. Return to add another task or the Add menu ");
            int Option1 = Integer.parseInt(Option2);
            if (Option1 == 1){
                TaskStat = " Done " ;
                PrintTaskDetails();
                JOptionPane.showMessageDialog(null,"Task status " + TaskStat + "\n" +
                "Developer details: " + DevName + " " + DevSur  + "\n" +
                "Task Number: " + TaskNumber + "\n" +
                "Task Name: " + TaskName + "\n" +
                "Task Description: " + TaskDesc+ "\n" +
                "Task Id: "+ TaskID + "\n" +
                "Task Duration: " + TotalHours);
            }
        else if (Option1 == 2) {
             TaskStat = " To Do " ;
                PrintTaskDetails();
                JOptionPane.showMessageDialog(null,"Task status " + TaskStat + "\n" +
                "Developer details: " + DevName + " " + DevSur  + "\n" +
                "Task Number: " + TaskNumber + "\n" +
                "Task Name: " + TaskName + "\n" +
                "Task Description: " + TaskDesc+ "\n" +
                "Task Id: "+ TaskID + "\n" +
                "Task Duration: " + TaskDur);
                }
        else if (Option1 == 3) {
             TaskStat = " Doing " ;
                PrintTaskDetails();
                JOptionPane.showMessageDialog(null,"Task status " + TaskStat + "\n" +
                "Developer details: " + DevName + " " + DevSur  + "\n" +
                "Task Number: " + TaskNumber + "\n" +
                "Task Name: " + TaskName + "\n" +
                "Task Description: " + TaskDesc+ "\n" +
                "Task Id: "+ TaskID + "\n" +
                "Task Duration: " + TaskDur);
        }
        else if (Option1 == 4) {
            
            break;
        }
        
        }while(true);
    }
}
    
 

    
    
    
      
    
       

